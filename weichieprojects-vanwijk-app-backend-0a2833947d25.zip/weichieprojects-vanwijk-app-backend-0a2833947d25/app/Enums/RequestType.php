<?php

namespace App\Enums;

class RequestType {

     const OPEN = 'open';
     const ON_HOLD = 'onhold';
     const REFUSED = 'refused';
     const CLOSED = 'closed';

}

<?php

namespace App\Enums;

class OrganisationType
{
    const DEPOT = 22; // References the depot organisation_type id from odoo
    const FUNERAL_DIRECTOR = 17;
}

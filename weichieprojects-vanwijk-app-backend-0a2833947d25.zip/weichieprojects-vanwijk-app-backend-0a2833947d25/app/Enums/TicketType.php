<?php

namespace App\Enums;

class TicketType {

     const OPEN = 'open';
     const WAITING = 'waiting'; //wachtend op antwoord van eindgebruiker
     const ON_HOLD = 'onhold';
     const CLOSED = 'closed';
     const ARCHIVE = 'archive';

}

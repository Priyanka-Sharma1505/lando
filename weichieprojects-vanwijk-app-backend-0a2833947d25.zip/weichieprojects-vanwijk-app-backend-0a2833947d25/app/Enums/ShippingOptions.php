<?php

namespace App\Enums;

use Illuminate\Support\Collection;

class ShippingOptions
{
    const A = 9176; // Binnen 2 dagen
    const B = 9174; // Binnn 1 dag
    const C = 9175; // Binnen 6 uur
}

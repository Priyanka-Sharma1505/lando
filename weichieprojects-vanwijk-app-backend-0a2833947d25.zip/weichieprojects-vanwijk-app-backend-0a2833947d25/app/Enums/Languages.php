<?php

namespace App\Enums;

class Languages
{
    const NL = 'nl_NL';
    const EN = 'en_US';
}
